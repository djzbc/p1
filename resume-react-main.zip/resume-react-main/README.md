# Static Resume

## Introduction:

Simple Static Page containing Resume information
[Pdf Format of Resume](https://drive.google.com/file/d/11_eqT_XApCBIQ0rw-UTZGo4vpBMXzybx/view?usp=share_link)

## Tools and Technologies Used:

- React
- Vite
- Css

## Todo:

- [x] Header
  - [x] Name
  - [x] Personal Info
- [x] Introduction/Objective
- [x] Education History
  - [x] PG Program
  - [x] UG Program
  - [x] PUC
  - [x] 10th
- [x] Skills
  - [x] Programming Technologies
  - [x] Web Technologies
  - [x] Databases
- [x] Projects
