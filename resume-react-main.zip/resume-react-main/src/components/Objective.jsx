import React, { Component } from "react";

export default class Objective extends Component {
  render() {
    return (
      <div className="objective">
        <h2>Introduction</h2>
        <p>
          A Passionate Student/Developer who enjoys adapting in both
          self-starting and collaborative environments while staying focused on
          achieving high-quality results under strict deadlines. Always eager to
          face challenges in life that will expand my knowledge which results in
          building my developer skills.
        </p>
      </div>
    );
  }
}
